<template>
  <div class="my-checkbox-group">
    <slot></slot>
  </div>
</template>

<script>
export default {
  componentName: 'myCheckboxGroup',
  props: {
    value: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  provide: function () {
    return {
      checkList: this.value,
      checkListChange: this.change
    }
  },
  methods: {
    change (b, label) {
      const index = this.value.findIndex(o => {
        return o === label
      })
      if (index !== -1) {
        this.value.splice(index, 1)
      } else {
        this.value.push(label)
      }
    }
  }
}
</script>

<style lang='scss'>
  .my-checkbox-group {
    .my-checkbox {
      margin-right: 30px;
    }
  }
</style>
