<template>
  <div class="child">
    <h4>这是子组件</h4>
    <input v-model.number="number" type="number" name="" id="">
    <!--
      2. 子组件触发这个事件，传递一个数字给父组件
     -->
    <button @click="$emit('update-num', number)">给父组件传递数字</button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      number: 1
    }
  }
}
</script>

<style scoped lang='scss'>
  .child {
    border: 1px solid pink;
    padding: 20px;
  }
  input {
    width: 500px;
    height: 30px;
  }
</style>
