<template>
  <div class="father">
    <h3>这是父组件(使用事件对象抛出一个值)</h3>
    这是父组件中的数据，子组件会传递数字给我做加法：{{ num }}
    <!--
      1. 给子组件绑定一个事件
      3. 父组件中要接受子组件中的数字，由于只有一行代码，要另起一个函数不方便，此时可以如下写法
        此时的$event就代表子组件传递过来的值
     -->
    <child @update-num="num += $event"></child>
  </div>
</template>

<script>
import child from './child.vue'
export default {
  data () {
    return {
      num: 0
    }
  },
  components: {
    child
  }
}
</script>

<style scoped lang='scss'>
</style>
