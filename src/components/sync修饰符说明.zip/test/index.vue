<template>
  <div class="father">
    <h3>这是父组件</h3>
    <!--
      1. 在子组件上绑定一个值并加上.sync修饰符
    -->
    <child :val.sync="val"></child>
  </div>
</template>

<script>
import child from './child.vue'
export default {
  data () {
    return {
      val: 'xxh'
    }
  },
  components: {
    child
  }
}
</script>

<style scoped lang='scss'>
</style>
