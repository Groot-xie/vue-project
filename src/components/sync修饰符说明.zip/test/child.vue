<template>
  <div class="child">
    <h4>这是子组件</h4>
    <div>这是父组件传过来的值： {{ val }}</div>
    <!--
      2. 加入.sync修饰符后, 相当于在子组件上默认绑定了一个update:val事件
      3. ‘update:’ 是固定写法, val是你用sync修饰符给子组件绑定的props
      4. 此时就可以触发这个事件, 把要改变的值传递过去
    -->
    <input type="text" @input="$emit('update:val', $event.target.value)" placeholder="在这里输入的文本会改变上面父组件传过来的值》。。">
  </div>
</template>

<script>
export default {
  props: {
    val: String
  }
}
</script>

<style scoped lang='scss'>
  .child {
    border: 1px solid pink;
    padding: 20px;
  }
  input {
    width: 500px;
    height: 30px;
  }
</style>
