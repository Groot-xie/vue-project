<template>
  <div class="father">
      <h2>component组件区域</h2>
      <component :is="componentId"></component>
      <button @click="change">点击切换组件</button>
  </div>
</template>

<script>
import one from './one.vue'
import two from './two.vue'
export default {
  data () {
    return {
      num: 0,
      componentId: 'one'
    }
  },
  components: {
    one,
    two
  },
  methods: {
    change () {
      this.componentId = this.componentId === 'one' ? 'two' : 'one'
    }
  },
  mounted () {
  }
}
</script>

<style scoped lang='scss'>
  .component {
    border: 1px solid red;
  }
</style>
