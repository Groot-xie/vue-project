<template>
  <div>组件2</div>
</template>

<script>
export default {

}
</script>

<style scoped lang='scss'>

</style>
