<template>
  <div>
    <h3>这是第一个子组件，可以改变父组件的数据</h3>
    <el-switch
      :value="checked"
      active-color="#13ce66"
      inactive-color="#ff4949"
      @change="$emit('update:checked', $event)"
    >
    </el-switch>
  </div>
</template>

<script>
export default {
  props: {
    checked: Boolean
  }
}
</script>

<style scoped lang='scss'>

</style>
