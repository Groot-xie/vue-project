<template>
  <div>
    <h3>这是第二个子组件，只展示数据</h3>
    <el-switch
      :value="checked"
      active-color="#13ce66"
      inactive-color="#ff4949">
    </el-switch>
  </div>
</template>

<script>
export default {
  props: {
    checked: Boolean
  }
}
</script>

<style scoped lang='scss'>

</style>
