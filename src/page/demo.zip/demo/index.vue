<template>
  <div>
    <child-one :checked.sync="isSelected"></child-one>
    <child-two :checked="isSelected"></child-two>
  </div>
</template>

<script>
import childOne from './child-one.vue'
import childTwo from './child-two.vue'
export default {
  data () {
    return {
      isSelected: true
    }
  },
  components: {
    childOne,
    childTwo
  }
}
</script>

<style scoped lang='scss'>

</style>
